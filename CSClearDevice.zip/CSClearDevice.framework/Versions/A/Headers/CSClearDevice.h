//
//  CSClearDevice.h
//  CSClearDevice
//
//  Created by Rodrigo Suhr on 9/8/16.
//  Copyright © 2016 ClearSale. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CSClearDevice : NSObject

+ (instancetype)getInstance;
- (void)setApp:(NSString *)app;
- (void)setSessionID:(NSString *)sessionID;
- (NSString *)getSessionID;
- (void)generateSessionID;
- (void)send;

@end
